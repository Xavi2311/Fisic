/*

String planeta = jList1.getSelectedValue();
         canviarPlaneta(planeta);
         canviarFoto(planeta);

         
public void canviarPlaneta(String planeta){
    nomPlaneta.setText(planeta);
}
public void canviarFoto(String planeta){
    String url=null;
    switch (planeta){
        case "Mart":
            url="/com/mycompany/mavenproject3/Imagenes/marte.jpg";
        break;
        case "Venus":
            url="/com/mycompany/mavenproject3/Imagenes/Venus.jpg";
        break;
        case "Ura":
            url="/com/mycompany/mavenproject3/Imagenes/Urano.jpg";
        break;
        case "Saturn":
            url="/com/mycompany/mavenproject3/Imagenes/Saturno.jpg";
        break;
        case "Mercuri":
            url="/com/mycompany/mavenproject3/Imagenes/Mercurio.jpg";
        break;
        case "Neptu":
            url="/com/mycompany/mavenproject3/Imagenes/Neptuno.jpg";
        break;
    }
    fotoPlanetaDestino.setIcon(new javax.swing.ImageIcon(getClass().getResource(url)));
}*/