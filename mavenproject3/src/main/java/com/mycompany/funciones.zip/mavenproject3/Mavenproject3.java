/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.mavenproject3;
/**
 *
 * @author xavia
 */
public class Mavenproject3 {

    public static void main(String[] args)throws Exception {
        NewJFrame frame = new NewJFrame();
        frame.setVisible(true);
        //Fisic fisic = new Fisic();
       // fisic.getRadi("Mart");
       CalcularCombustible a = new CalcularCombustible();
       a.setVisible(true);
    }
}
